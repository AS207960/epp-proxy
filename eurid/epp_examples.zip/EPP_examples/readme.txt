README FILE FOR THE REGISTRATION GUIDELINES PART 2: EPP and EPP Examples
* This document describes the content of the zip file for the Registration Guidelines part 2: EPP and EPP examples.
* The zip file provides XML files stored in folders, which correspond to the main chapters of these Registration Guidelines.
